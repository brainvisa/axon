from neuroProcesses import *
from brainvisa import anatomist
import shfjGlobals

roles = [ 'viewer' ]

signature = Signature(
  'input', ReadDiskItem( 'Hemisphere white+grey Mesh', 'Mesh Mesh' ),
  'mri', ReadDiskItem( 'Raw T1 MRI', shfjGlobals.anatomistVolumeFormats ),
)

def initialization( self ):
  self.setOptional( 'mri' )
  self.linkParameters( 'mri', 'input' )

def execution( self, context ):
  a = anatomist.Anatomist()
  mesh = a.loadObject( self.input )
  objects = [ mesh ]
  show = mesh
  win = a.createWindow( '3D' )
  mat = mesh.material
  mat.diffuse = [ 1., 0.5, 0.7, 1. ]
  mat.face_culling = 0
  mesh.setMaterial( mat )
  if self.mri:
    mri = a.loadObject( self.mri )
    objects.append( mri )
    cut = a.fusionObjects( objects=[mesh, mri], method='FusionCutMeshMethod' )
    objects.append( cut )
    win.addObjects( [ cut ] )
    win.setControl( 'CutControl' )
  else:
    win.addObjects( [ mesh ] )
    a.execute( 'WindowConfig', windows=[win], clipping=1 )

  return objects + [ win ]

